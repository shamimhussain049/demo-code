import React, { Component } from 'react'
import QrReader from 'react-qr-scanner'
import { Audio } from 'react-loader-spinner'

class ReadQR extends Component {
  constructor(props){
    super(props)
    this.state = {
      isProcessing : false,
      postData: null
    }

    this.handleScan = this.handleScan.bind(this)
  }
  handleScan(data){
  	if(data!=null){
	    this.setState({
	    	isProcessing:true
	    })
		this.sendPost(data.result)
	}

  }
  async sendPost(machine_id) {

  	const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
    };
    fetch('https://reqres.in/api/users/1', requestOptions)
        .then(response => response.json())
        .then(data =>{ 
        	this.setState({ postData  : JSON.stringify(data) })});


  	setTimeout(function(){this.setState({isProcessing:false})}.bind(this),1000)

  }
  handleError(err){
    console.error(err)
  }
  renderElement(){
  	if(this.state.isProcessing){
  		return <Audio
					  height="80"
					  width="80"
					  radius="9"
					  color="green"
					  ariaLabel="loading"
					  wrapperStyle
					  wrapperClass
					/>;
  	}
  	else if(this.state.postData!=null){
  		return <p>{this.state.postData}</p>;
  	}
  	else{

    const previewStyle = {
      height: 240,
      width: 320,
    }
  		return  <div>
			        <QrReader
			          delay={this.state.delay}
			          style={previewStyle}
			          onError={this.handleError}
			          onScan={this.handleScan}
			          />
			      </div>;
  	}
  }
  render(){

    return(
	    	this.renderElement()
      )
  }
}

export default ReadQR;
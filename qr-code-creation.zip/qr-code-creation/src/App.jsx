import QRCode from 'qrcode'
import { useState } from 'react'
//Main URL for REST APi, Api end points for inserting , getting and inserting session .
// E.g Main API Address : https://reqres.in/api
// End points example: /machine/Abc1234 => get Request => response [machine_id,dormitory,status[vacant,in_use]]
// End points example: /machine/insert (Body : [machine_id,dormitory]) =>  Post Request

// Request data and response data for each end point => what we give and what we get

function App() {
  const [machine_id,setMachineID] = useState('') //State variables for form data
  const [dormitory,setDormitory] = useState('') //State variables for form data
  const [qr, setQr] = useState('') //State variables for form data

  const CreateNewMachine = () => { // Create NEw Machine i.e. Insert db to database utitilzing Rest API POST Endpoint
    const requestOptions = {
        method: 'POSt',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({"machine_id":machine_id,"dormitory":dormitory})
    };
    fetch('https://reqres.in/api/users/', requestOptions)
        .then(response => response.json())
        .then(data =>{ 
          GenerateQRCode(data)
        })
  }

  const GenerateQRCode = (data) => { // Generating QR code once the api adds data to db and returns success object
    var value = JSON.stringify({"machine_id":data.machine_id,"id":data.id,"dormitory":data.dormitory}) // extracting machine information from api return object
    QRCode.toDataURL(value, {
      width: 800,
      margin: 2,
      color: {
        dark: '#335383FF',
        light: '#EEEEEEFF'
      }
    }, (err, value) => {
      if (err) return console.error(err)

      console.log(qr)
      setQr(value)
    })
  }

  return (
    <div className="app">
      <h1>QR Generator</h1>
      <input 
        type="text"
        placeholder="Machine ID: ABC123"
        value={machine_id}
        onChange={e => setMachineID(e.target.value)} />
      <input 
        type="text"
        placeholder="dormitory : JosefStr 5"
        value={dormitory}
        onChange={e => setDormitory(e.target.value)} />
      <button onClick={CreateNewMachine}>Generate</button>
      {qr && <>
        <img src={qr} />
        <a href={qr} download="qrcode.png">Download</a>
      </>}
    </div>
  )
}

export default App